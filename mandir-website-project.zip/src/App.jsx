import React, { useEffect, useMemo, useState } from "react";
import {
  GoogleAuthProvider, FacebookAuthProvider, signInWithPopup, signInWithEmailAndPassword,
  createUserWithEmailAndPassword, sendPasswordResetEmail, signOut, onAuthStateChanged,
  RecaptchaVerifier, signInWithPhoneNumber, updateProfile
} from "firebase/auth";
import { collection, addDoc, deleteDoc, doc, onSnapshot, orderBy, query, serverTimestamp, setDoc } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { auth, db, storage, firebaseReady, adminEmails } from "./firebase";
import { BookOpen, Camera, Clock3, Globe2, History, Home, LogIn, LogOut, Menu, Plus, Settings, Shield, Sparkles, Trash2, Upload, User, X } from "lucide-react";

const starter = {
  siteName: "શ્રી મંદિર",
  tagline: "ભક્તિ, જ્ઞાન અને સંસ્કૃતિનું પવિત્ર સ્થાન",
  welcome: "આપનું હાર્દિક સ્વાગત છે",
  heroImage: "",
  about: "આપણા મંદિરની પરંપરા, સેવા અને આધ્યાત્મિક વારસાની માહિતી અહીં વાંચો."
};
const sections = [
  {id:"home", label:"Home", icon:Home}, {id:"shlok",label:"Shlok & Mantra",icon:BookOpen},
  {id:"history",label:"History",icon:History}, {id:"gallery",label:"Gallery",icon:Camera}
];
function App(){
  const [user,setUser]=useState(null), [page,setPage]=useState("home"), [mobileMenu,setMobileMenu]=useState(false);
  const [site,setSite]=useState(starter), [items,setItems]=useState([]), [photos,setPhotos]=useState([]);
  const [loginOpen,setLoginOpen]=useState(false), [adminOpen,setAdminOpen]=useState(false);
  const [notice,setNotice]=useState(""), [busy,setBusy]=useState(false);
  const isAdmin=!!user && adminEmails.includes((user.email||"").toLowerCase());
  useEffect(()=>{ if(!auth) return; return onAuthStateChanged(auth,setUser); },[]);
  useEffect(()=>{
    if(!db) return;
    const a=onSnapshot(doc(db,"public","settings"),s=>{if(s.exists())setSite({...starter,...s.data()});});
    const b=onSnapshot(query(collection(db,"content"),orderBy("createdAt","desc")),s=>setItems(s.docs.map(d=>({id:d.id,...d.data()}))));
    const c=onSnapshot(query(collection(db,"gallery"),orderBy("createdAt","desc")),s=>setPhotos(s.docs.map(d=>({id:d.id,...d.data()}))));
    return ()=>{a();b();c();};
  },[]);
  const msg=(s)=>{setNotice(s);setTimeout(()=>setNotice(""),4000)};
  async function social(provider){try{await signInWithPopup(auth,provider);setLoginOpen(false);msg("Login successful.");}catch(e){msg(e.message)}}
  async function emailLogin(email,password,create=false){try{if(create)await createUserWithEmailAndPassword(auth,email,password);else await signInWithEmailAndPassword(auth,email,password);setLoginOpen(false);msg("Welcome!");}catch(e){msg(e.message)}}
  async function reset(email){try{await sendPasswordResetEmail(auth,email);msg("Password reset email sent.");}catch(e){msg(e.message)}}
  async function phoneLogin(number){try{if(!window.recaptchaVerifier)window.recaptchaVerifier=new RecaptchaVerifier(auth,"recaptcha-container",{size:"normal"});const c=await signInWithPhoneNumber(auth,number,window.recaptchaVerifier);const code=prompt("SMS verification code enter karein");if(code)await c.confirm(code);setLoginOpen(false);}catch(e){msg(e.message)}}
  async function saveSettings(next){if(!isAdmin)return;await setDoc(doc(db,"public","settings"),next,{merge:true});setSite(next);msg("Website settings saved.");}
  async function addContent(data){if(!isAdmin)return;await addDoc(collection(db,"content"),{...data,createdAt:serverTimestamp()});msg("Content added.");}
  async function removeContent(id){if(!isAdmin||!confirm("Delete this item?"))return;await deleteDoc(doc(db,"content",id));}
  async function uploadPhoto(file){if(!isAdmin||!file)return;const path=`gallery/${Date.now()}-${file.name}`;const r=ref(storage,path);await uploadBytes(r,file);const url=await getDownloadURL(r);await addDoc(collection(db,"gallery"),{url,name:file.name,createdAt:serverTimestamp()});msg("Photo uploaded.");}
  async function deletePhoto(id){if(isAdmin&&confirm("Delete this photo?"))await deleteDoc(doc(db,"gallery",id));}
  return <div className="app">
    <header className="top"><button className="brand" onClick={()=>setPage("home")}><span className="om">ॐ</span><span><b>{site.siteName}</b><small>{site.tagline}</small></span></button><nav>{sections.map(s=><button className={page===s.id?"active":""} onClick={()=>setPage(s.id)} key={s.id}><s.icon size={17}/>{s.label}</button>)}</nav><div className="head-actions">{user?<><span className="user-label"><User size={16}/>{user.displayName||user.email||user.phoneNumber}</span><button className="outline" onClick={()=>signOut(auth)}><LogOut size={16}/> Logout</button></>:<button className="primary" onClick={()=>setLoginOpen(true)}><LogIn size={16}/> Login / Account</button>}{isAdmin&&<button className="outline" onClick={()=>setAdminOpen(true)}><Settings size={16}/> Admin</button>}</div><button className="hamb" onClick={()=>setMobileMenu(!mobileMenu)}><Menu/></button></header>
    {mobileMenu&&<div className="mobile-nav">{sections.map(s=><button onClick={()=>{setPage(s.id);setMobileMenu(false)}} key={s.id}>{s.label}</button>)}<button onClick={()=>setLoginOpen(true)}>Login / Account</button></div>}
    {page==="home"&&<><section className="hero" style={site.heroImage?{backgroundImage:`linear-gradient(90deg,rgba(28,13,5,.83),rgba(28,13,5,.18)),url("${site.heroImage}")`}:{}}><div className="hero-content"><span className="eyebrow"><Sparkles size={15}/> DIVINE • PEACE • DEVOTION</span><h1>{site.welcome}</h1><p>{site.tagline}</p><button className="gold" onClick={()=>setPage("shlok")}>Explore Shlok & Mantra <span>→</span></button></div></section><section className="welcome"><div><span className="eyebrow dark">WELCOME TO OUR TEMPLE</span><h2>{site.siteName}</h2><p>{site.about}</p></div><div className="feature-grid">{sections.slice(1).map(s=><button className="feature" key={s.id} onClick={()=>setPage(s.id)}><s.icon/><b>{s.label}</b><span>Explore →</span></button>)}</div></section></>}
    {page==="shlok"&&<ContentPage title="Shlok & Mantra" subtitle="પવિત્ર શ્લોકો અને મંત્રો" items={items.filter(x=>x.type!=="history")} isAdmin={isAdmin} onAdd={addContent} onDelete={removeContent}/>}
    {page==="history"&&<ContentPage title="Mandir History" subtitle="મંદિરનો ઇતિહાસ અને પરંપરા" items={items.filter(x=>x.type==="history")} isAdmin={isAdmin} onAdd={addContent} onDelete={removeContent} history/>}
    {page==="gallery"&&<section className="content"><div className="section-head"><div><span className="eyebrow dark">PHOTO COLLECTION</span><h2>Mandir Gallery</h2></div>{isAdmin&&<label className="primary upload"><Upload size={16}/> Upload Photo<input type="file" accept="image/*" onChange={e=>uploadPhoto(e.target.files?.[0])}/></label>}</div><div className="gallery">{photos.map(p=><div className="photo" key={p.id}><img src={p.url}/>{isAdmin&&<button onClick={()=>deletePhoto(p.id)}><Trash2 size={16}/></button>}</div>)}</div>{!photos.length&&<p className="empty">Photos will appear here.</p>}</section>}
    <footer><span className="om small-om">ॐ</span><b>{site.siteName}</b><p>{site.tagline}</p><small>Made with devotion • {new Date().getFullYear()}</small></footer>
    {notice&&<div className="toast">{notice}</div>}
    {loginOpen&&<LoginModal onClose={()=>setLoginOpen(false)} onSocial={social} onEmail={emailLogin} onReset={reset} onPhone={phoneLogin}/>}
    {adminOpen&&<AdminModal site={site} onSave={saveSettings} onClose={()=>setAdminOpen(false)}/>}
  </div>
}
function ContentPage({title,subtitle,items,isAdmin,onAdd,onDelete,history=false}){
 const [search,setSearch]=useState("");
 const shown=items.filter(x=>(x.title||"").toLowerCase().includes(search.toLowerCase())||(x.body||"").toLowerCase().includes(search.toLowerCase()));
 return <section className="content"><div className="section-head"><div><span className="eyebrow dark">{subtitle}</span><h2>{title}</h2></div><input className="search" placeholder="Search..." value={search} onChange={e=>setSearch(e.target.value)}/></div>{isAdmin&&<AddContent history={history} onAdd={onAdd}/>}<div className="content-list">{shown.map(x=><article className="verse" key={x.id}><div className="verse-top"><span>{x.type==="history"?"HISTORY":x.language||"SANSKRIT"}</span>{isAdmin&&<button className="delete" onClick={()=>onDelete(x.id)}><Trash2 size={16}/></button>}</div><h3>{x.title}</h3><p className="verse-body">{x.body}</p>{x.meaning&&<p className="meaning"><b>Meaning:</b> {x.meaning}</p>}</article>)}</div>{!shown.length&&<p className="empty">No content yet. Admin can add content here.</p>}</section>
}
function AddContent({history,onAdd}){
 const [title,setTitle]=useState(""),[body,setBody]=useState(""),[meaning,setMeaning]=useState(""),[language,setLanguage]=useState("Sanskrit");
 return <form className="add-form" onSubmit={e=>{e.preventDefault();if(title.trim()&&body.trim()){onAdd({title,body,meaning,language,type:history?"history":"mantra"});setTitle("");setBody("");setMeaning("");}}}><h3><Plus size={18}/> Add {history?"history":"shlok / mantra"}</h3><input required placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)}/><textarea required placeholder={history?"Write history...":"Write shlok or mantra..."} value={body} onChange={e=>setBody(e.target.value)}/>{!history&&<><input placeholder="Meaning / translation (optional)" value={meaning} onChange={e=>setMeaning(e.target.value)}/><select value={language} onChange={e=>setLanguage(e.target.value)}><option>Sanskrit</option><option>Gujarati</option><option>Hindi</option><option>English</option></select></>}<button className="primary" type="submit">Publish</button></form>
}
function LoginModal({onClose,onSocial,onEmail,onReset,onPhone}){
 const [mode,setMode]=useState("login"),[email,setEmail]=useState(""),[password,setPassword]=useState(""),[phone,setPhone]=useState("");
 return <div className="shade"><div className="modal"><button className="close" onClick={onClose}><X/></button><span className="om modal-om">ॐ</span><h2>{mode==="create"?"Create Account":mode==="reset"?"Forgot Password":"Welcome Back"}</h2><p>Sign in to your Mandir account</p><form onSubmit={e=>{e.preventDefault();mode==="reset"?onReset(email):onEmail(email,password,mode==="create")}}><input type="email" required placeholder="Email address" value={email} onChange={e=>setEmail(e.target.value)}/>{mode!=="reset"&&<input type="password" required minLength="6" placeholder="Password (minimum 6 characters)" value={password} onChange={e=>setPassword(e.target.value)}/>}<button className="primary full" type="submit">{mode==="create"?"Create account":mode==="reset"?"Send reset email":"Login with email"}</button></form><div className="modal-links">{mode==="login"&&<><button onClick={()=>setMode("reset")}>Forgot password?</button><button onClick={()=>setMode("create")}>Create new account</button></>}{mode!=="login"&&<button onClick={()=>setMode("login")}>Back to login</button>}</div><div className="or">OR CONTINUE WITH</div><button className="social" onClick={()=>onSocial(new GoogleAuthProvider())}>Google</button><button className="social" onClick={()=>onSocial(new FacebookAuthProvider())}>Facebook</button><div className="phone-row"><input placeholder="+91 mobile number" value={phone} onChange={e=>setPhone(e.target.value)}/><button className="outline" onClick={()=>onPhone(phone)}>Send OTP</button></div><div id="recaptcha-container"></div><small className="hint">Google, Facebook and phone login must be enabled in your Firebase project.</small></div></div>
}
function AdminModal({site,onSave,onClose}){
 const [form,setForm]=useState(site);const change=(k,v)=>setForm(p=>({...p,[k]:v}));
 return <div className="shade"><div className="modal admin-modal"><button className="close" onClick={onClose}><X/></button><span className="eyebrow dark"><Shield size={14}/> OWNER CONTROL PANEL</span><h2>Website Settings</h2><label>Website name<input value={form.siteName||""} onChange={e=>change("siteName",e.target.value)}/></label><label>Tagline<input value={form.tagline||""} onChange={e=>change("tagline",e.target.value)}/></label><label>Home welcome heading<input value={form.welcome||""} onChange={e=>change("welcome",e.target.value)}/></label><label>About the temple<textarea value={form.about||""} onChange={e=>change("about",e.target.value)}/></label><label>Hero image URL<input value={form.heroImage||""} onChange={e=>change("heroImage",e.target.value)} placeholder="Paste image URL (or upload in Gallery)"/></label><button className="primary full" onClick={()=>onSave(form)}>Save website settings</button></div></div>
}
export default App;