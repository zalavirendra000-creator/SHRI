# Mandir Website (Gujarati + Hindi + English ready)

A responsive React + Firebase starter project for a temple website. It includes a public home page, shlok/mantra and history sections, photo gallery, account/login UI, and an owner settings panel.

## 1. Run on your computer

Install Node.js (LTS), then in this folder run:

```bash
npm install
cp .env.example .env
npm run dev
```

Open the local address printed by Vite.

## 2. Connect Firebase (required for real accounts and cloud editing)

1. Create a Firebase project at https://console.firebase.google.com/
2. Register a Web App and copy its config into `.env`.
3. Enable **Authentication** providers you want: Email/Password, Google, Facebook, and Phone.
4. For Facebook, create a Meta app and configure its OAuth redirect URI in Firebase. Facebook sign-in will not work until this is configured.
5. Create a Firestore database and enable Firebase Storage.
6. Copy `firestore.rules` into Firestore Rules and `storage.rules` into Storage Rules.
7. Replace `YOUR_ADMIN_EMAIL@example.com` in both rules with the exact email used by the owner account.
8. Set `VITE_ADMIN_EMAILS` in `.env` to that same email.
9. Add your website domain to Firebase Authentication > Settings > Authorized domains.
10. Restart the dev server after editing `.env`.

**Important:** The admin email in frontend environment variables only controls what admin controls are displayed. The Firestore and Storage security rules are the actual protection. Never publish with placeholder admin emails/rules.

## 3. Phone login

Firebase Phone Authentication requires an authorized domain and reCAPTCHA. Add test phone numbers in Firebase Authentication for development. Real SMS may incur Firebase billing/quotas. Use a trusted adult's help to configure billing and account ownership.

## 4. Deploy

Build with `npm run build`. Deploy the `dist` folder to Firebase Hosting, Netlify, or another static host. Configure the same environment variables in the hosting provider. For Firebase Hosting, install the Firebase CLI and follow its Hosting setup instructions.

## 5. Included features

- Responsive mobile and desktop layout
- Gujarati-friendly font with Hindi and English text support
- Email sign-up/login and password reset
- Google, Facebook and phone OTP sign-in UI (providers must be enabled/configured)
- Owner-only website name, tagline, welcome text and about section editing
- Owner-only shlok/mantra and history publishing/deletion
- Photo upload and gallery
- Live updates from Firestore

## Notes / next improvements

- Add an actual language switcher and translated page labels.
- Add profile editing, user roles managed server-side, and audit logs.
- Add a proper hero-image file picker (gallery uploads are already supported).
- Add account deletion and privacy/terms pages before public launch.
- Review security rules and test with a non-admin account before sharing publicly.

This starter does not include a live Firebase project, domain, or production credentials. You must connect your own Firebase project to activate online authentication and storage.